let checkoutConfig = {}
let cartData = null
let phoneVerified = false
let otpId = null
let Razorpay // Declare Razorpay variable

function InitializeCheckout(csrfToken, cartUrl, createOrderUrl, verifyPaymentUrl, sendOtpUrl, verifyOtpUrl) {
  checkoutConfig = {
    csrfToken,
    cartUrl,
    createOrderUrl,
    verifyPaymentUrl,
    sendOtpUrl,
    verifyOtpUrl,
  }

  loadCartData()
  setupEventListeners()
}

function setupEventListeners() {
  // Billing address toggle
  document.getElementById("differentBillingAddress").addEventListener("change", (e) => {
    document.getElementById("billing-address-section").style.display = e.target.checked ? "block" : "none"
  })

  // Phone number change - reset verification
  document.getElementById("phone").addEventListener("input", () => {
    phoneVerified = false
    document.getElementById("phone-verify-container").innerHTML = ""
  })

  // Phone blur - trigger OTP sending
  document.getElementById("phone").addEventListener("blur", function () {
    const phone = this.value.trim()
    if (phone.length === 10 && !phoneVerified) {
      sendOTP(phone)
    }
  })

  // Place order button
  document.getElementById("place-order-btn").addEventListener("click", handlePlaceOrder)
}

async function loadCartData() {
  try {
    const [success, response] = await callApi("GET", checkoutConfig.cartUrl, null, checkoutConfig.csrfToken)

    if (response.success && response.data) {
      cartData = response.data
      if (!cartData.items || cartData.items.length === 0) {
        alert("Cart is empty")
        window.location.href = "/cart"
        return
      }
      renderCheckoutItems()
    } else {
      alert("Cart is empty")
      window.location.href = "/cart"
    }
  } catch (error) {
    console.error("[v0] Error loading cart:", error)
    alert("Failed to load cart data")
  }
}

function renderCheckoutItems() {
  const itemsContainer = document.getElementById("checkout-items")
  itemsContainer.innerHTML = ""

  let subtotal = 0

  cartData.items.forEach((item) => {
    const price = Number.parseFloat(item.listing_unit.price)
    subtotal += price

    const itemHTML = `
            <div class="order-item">
                <div class="item-info">
                    <h6>${item.brand_name} ${item.model_name}</h6>
                    <p class="text-muted mb-0">${item.attributes_display}</p>
                    <small>Condition: ${item.condition_display}</small>
                </div>
                <div class="item-price">₹${price.toFixed(2)}</div>
            </div>
        `
    itemsContainer.innerHTML += itemHTML
  })

  const shipping = 50.0
  const tax = 0.0
  const total = subtotal + shipping + tax

  document.getElementById("checkout-subtotal").textContent = `₹${subtotal.toFixed(2)}`
  document.getElementById("checkout-shipping").textContent = `₹${shipping.toFixed(2)}`
  document.getElementById("checkout-tax").textContent = `₹${tax.toFixed(2)}`
  document.getElementById("checkout-total").textContent = `₹${total.toFixed(2)}`
}

async function sendOTP(phone) {
  try {
    const [success, response] = await callApi(
      "POST",
      checkoutConfig.sendOtpUrl,
      { mobile: phone },
      checkoutConfig.csrfToken,
    )

    if (response.success) {
      otpId = response.data.otp_id
      showOTPInput()
    } else {
      alert("Failed to send OTP: " + (response.error || "Unknown error"))
    }
  } catch (error) {
    console.error("[v0] Error sending OTP:", error)
    alert("Failed to send OTP")
  }
}

function showOTPInput() {
  const container = document.getElementById("phone-verify-container")
  container.innerHTML = `
        <div class="mt-2">
            <label for="otp" class="form-label">Enter OTP *</label>
            <div class="input-group">
                <input type="text" class="form-control" id="otp" placeholder="Enter 6-digit OTP" maxlength="6">
                <button class="btn btn-primary" type="button" id="verify-otp-btn">Verify</button>
            </div>
            <small class="text-muted">OTP sent to your mobile number</small>
        </div>
    `

  document.getElementById("verify-otp-btn").addEventListener("click", verifyOTP)
}

async function verifyOTP() {
  const otp = document.getElementById("otp").value.trim()
  if (otp.length !== 6) {
    alert("Please enter valid 6-digit OTP")
    return
  }

  try {
    const [success, response] = await callApi(
      "PUT",
      `${checkoutConfig.verifyOtpUrl}${otpId}/`,
      { otp: otp, role: "customer" },
      checkoutConfig.csrfToken,
    )

    if (response.success && response.data.otp_verified) {
      phoneVerified = true
      document.getElementById("phone-verify-container").innerHTML = `
                <small class="text-success"><i class="fas fa-check-circle"></i> Phone verified</small>
            `
    } else {
      alert("Invalid OTP. Please try again.")
    }
  } catch (error) {
    console.error("[v0] Error verifying OTP:", error)
    alert("Failed to verify OTP")
  }
}

async function handlePlaceOrder() {
  // Validate form
  const form = document.getElementById("checkout-form")
  if (!form.checkValidity()) {
    form.reportValidity()
    return
  }

  // Check phone verification
  if (!phoneVerified) {
    alert("Please verify your phone number")
    return
  }

  const phone = document.getElementById("phone").value.trim()
  const billingSameAsShipping = !document.getElementById("differentBillingAddress").checked

  const orderData = {
    first_name: document.getElementById("firstName").value.trim(),
    last_name: document.getElementById("lastName").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone: phone,
    shipping_address: document.getElementById("address").value.trim(),
    shipping_city: document.getElementById("city").value.trim(),
    shipping_state: document.getElementById("state").value.trim(),
    shipping_pincode: document.getElementById("pincode").value.trim(),
    billing_same_as_shipping: billingSameAsShipping,
    billing_address: billingSameAsShipping ? "" : document.getElementById("billingAddress").value.trim(),
    billing_city: billingSameAsShipping ? "" : document.getElementById("billingCity").value.trim(),
    billing_state: billingSameAsShipping ? "" : document.getElementById("billingState").value.trim(),
    billing_pincode: billingSameAsShipping ? "" : document.getElementById("billingPincode").value.trim(),
    payment_method: document.querySelector('input[name="paymentMethod"]:checked').value,
    order_notes: document.getElementById("orderNotes").value.trim(),
  }

  const btn = document.getElementById("place-order-btn")
  const spinner = document.getElementById("place-order-spinner")
  btn.disabled = true
  spinner.style.display = "inline-block"

  try {
    const [success, response] = await callApi(
      "POST",
      checkoutConfig.createOrderUrl,
      orderData,
      checkoutConfig.csrfToken,
    )

    if (response.success) {
      if (orderData.payment_method === "razorpay") {
        openRazorpayPayment(response.data, orderData)
      } else {
        // COD - redirect to success page
        alert("Order placed successfully!")
        window.location.href = `/order-success?order_id=${response.data.order_id}`
      }
    } else {
      alert("Failed to create order: " + (response.error || "Unknown error"))
      btn.disabled = false
      spinner.style.display = "none"
    }
  } catch (error) {
    console.error("[v0] Error placing order:", error)
    alert("Failed to place order")
    btn.disabled = false
    spinner.style.display = "none"
  }
}

function openRazorpayPayment(orderData, customerData) {
  const options = {
    key: "YOUR_RAZORPAY_KEY_ID",
    amount: orderData.razorpay_order.amount,
    currency: "INR",
    name: "RefurBazaar",
    description: "Order Payment",
    order_id: orderData.razorpay_order.id,
    handler: (response) => {
      verifyRazorpayPayment(response, orderData.order_id)
    },
    prefill: {
      name: `${customerData.first_name} ${customerData.last_name}`,
      email: customerData.email,
      contact: customerData.phone,
    },
    theme: {
      color: "#007bff",
    },
    modal: {
      ondismiss: () => {
        document.getElementById("place-order-btn").disabled = false
        document.getElementById("place-order-spinner").style.display = "none"
      },
    },
  }

  Razorpay = window.Razorpay // Assign Razorpay from window object
  const razorpay = new Razorpay(options)
  razorpay.open()
}

async function verifyRazorpayPayment(razorpayResponse, orderId) {
  try {
    const verifyData = {
      order_id: orderId,
      razorpay_order_id: razorpayResponse.razorpay_order_id,
      razorpay_payment_id: razorpayResponse.razorpay_payment_id,
      razorpay_signature: razorpayResponse.razorpay_signature,
    }

    const [success, response] = await callApi(
      "POST",
      checkoutConfig.verifyPaymentUrl,
      verifyData,
      checkoutConfig.csrfToken,
    )

    if (response.success) {
      alert("Payment successful!")
      window.location.href = `/order-success?order_id=${orderId}`
    } else {
      alert("Payment verification failed")
    }
  } catch (error) {
    console.error("[v0] Error verifying payment:", error)
    alert("Payment verification failed")
  }
}
