from rest_framework import serializers
from .models import Order, OrderItem
from Product.serializers import ListingUnitSerializer


class OrderItemSerializer(serializers.ModelSerializer):
    """Serializer for OrderItem with product details"""
    listing_unit = ListingUnitSerializer(read_only=True)
    brand_name = serializers.SerializerMethodField()
    model_name = serializers.SerializerMethodField()
    product_image = serializers.SerializerMethodField()
    
    class Meta:
        model = OrderItem
        fields = [
            'id', 'listing_unit', 'price_at_purchase', 'condition_at_purchase',
            'refurbisher', 'refurbisher_name', 'brand_name', 'model_name',
            'product_image', 'created_at'
        ]
    
    def get_brand_name(self, obj):
        return obj.listing_unit.listing.model.brand.name
    
    def get_model_name(self, obj):
        return obj.listing_unit.listing.model.name
    
    def get_product_image(self, obj):
        if obj.listing_unit.listing.model.image:
            return obj.listing_unit.listing.model.image.url
        return None


class OrderSerializer(serializers.ModelSerializer):
    """Serializer for Order with nested items"""
    items = OrderItemSerializer(many=True, read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)
    
    class Meta:
        model = Order
        fields = [
            'id', 'order_id', 'order_number', 'user', 'session_id',
            'first_name', 'last_name', 'email', 'phone',
            'shipping_address', 'shipping_city', 'shipping_state', 'shipping_pincode',
            'billing_same_as_shipping', 'billing_address', 'billing_city', 
            'billing_state', 'billing_pincode',
            'subtotal', 'tax_amount', 'shipping_charge', 'total_amount',
            'payment_method', 'payment_method_display', 'razorpay_order_id', 
            'razorpay_payment_id', 'payment_status',
            'status', 'status_display', 'order_notes', 'items',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['order_id', 'order_number', 'created_at', 'updated_at']


class OrderCreateSerializer(serializers.Serializer):
    """Serializer for creating an order from cart"""
    cart_id = serializers.CharField(required=True)
    first_name = serializers.CharField(max_length=100)
    last_name = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    phone = serializers.CharField(max_length=15)
    shipping_address = serializers.CharField()
    shipping_city = serializers.CharField(max_length=100)
    shipping_state = serializers.CharField(max_length=100)
    shipping_pincode = serializers.CharField(max_length=10)
    billing_same_as_shipping = serializers.BooleanField(default=True)
    billing_address = serializers.CharField(required=False, allow_blank=True)
    billing_city = serializers.CharField(max_length=100, required=False, allow_blank=True)
    billing_state = serializers.CharField(max_length=100, required=False, allow_blank=True)
    billing_pincode = serializers.CharField(max_length=10, required=False, allow_blank=True)
    payment_method = serializers.ChoiceField(choices=['razorpay', 'cod'])
    order_notes = serializers.CharField(required=False, allow_blank=True)


class PaymentVerificationSerializer(serializers.Serializer):
    """Serializer for payment verification"""
    order_id = serializers.CharField()
    razorpay_order_id = serializers.CharField()
    razorpay_payment_id = serializers.CharField()
    razorpay_signature = serializers.CharField()
